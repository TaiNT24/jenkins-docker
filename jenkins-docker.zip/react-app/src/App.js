import React from 'react';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <h1>Hello World from React!</h1>
      </header>
    </div>
  );
}

export default App;